import React from 'react';
import { loadStripe } from '@stripe/stripe-js';
import axios from 'axios';

const stripePromise = loadStripe('YOUR_STRIPE_PUBLISHABLE_KEY');

const Payment: React.FC = () => {
    const handleClick = async () => {
        const stripe = await stripePromise;
        const token = localStorage.getItem('token');
        const response = await axios.post('/api/create-checkout-session/', {}, {
            headers: {
                'Authorization': `Token ${token}`
            }
        });
        const session = response.data;
        if (stripe) {
            const result = await stripe.redirectToCheckout({
                sessionId: session.id,
            });

            if (result.error) {
                console.error(result.error.message);
            }
        }
    };

    return (
        <button onClick={handleClick}>
            Buy More Credits
        </button>
    );
};

export default Payment;
