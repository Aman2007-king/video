import React, { useState } from 'react';
import axios from 'axios';

const VoiceGenerator: React.FC = () => {
    const [text, setText] = useState('');
    const [voiceGender, setVoiceGender] = useState('MALE');
    const [audio, setAudio] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setAudio(null);

        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('/api/generate-voice/', {
                text,
                voice_gender: voiceGender
            }, {
                headers: {
                    'Authorization': `Token ${token}`
                },
                responseType: 'arraybuffer'
            });
            const blob = new Blob([response.data], { type: 'audio/mpeg' });
            const url = URL.createObjectURL(blob);
            setAudio(url);
        } catch (error) {
            setError('Failed to generate voice');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Voice Generator</h2>
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Enter text to synthesize"
                />
                <select value={voiceGender} onChange={(e) => setVoiceGender(e.target.value)}>
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                </select>
                <button type="submit" disabled={loading}>
                    {loading ? 'Generating...' : 'Generate Voice'}
                </button>
            </form>
            {error && <p>{error}</p>}
            {audio && <audio src={audio} controls />}
        </div>
    );
};

export default VoiceGenerator;
