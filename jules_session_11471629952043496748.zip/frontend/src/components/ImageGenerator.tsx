import React, { useState } from 'react';
import axios from 'axios';

const ImageGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setImageUrl('');

        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('/api/generate-image/', {
                prompt
            }, {
                headers: {
                    'Authorization': `Token ${token}`
                }
            });
            setImageUrl(response.data.output_url);
        } catch (error) {
            setError('Failed to generate image');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Image Generator</h2>
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Enter a prompt"
                />
                <button type="submit" disabled={loading}>
                    {loading ? 'Generating...' : 'Generate Image'}
                </button>
            </form>
            {error && <p>{error}</p>}
            {imageUrl && <img src={imageUrl} alt="Generated" />}
        </div>
    );
};

export default ImageGenerator;
