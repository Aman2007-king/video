import React, { useState } from 'react';
import axios from 'axios';

const VideoGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [duration, setDuration] = useState(5);
    const [style, setStyle] = useState('realistic');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setVideoUrl('');

        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('/api/generate-video/', {
                prompt,
                duration,
                style
            }, {
                headers: {
                    'Authorization': `Token ${token}`
                }
            });
            setVideoUrl(response.data[0]);
        } catch (error) {
            setError('Failed to generate video');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Video Generator</h2>
                <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Enter a prompt"
                />
                <select value={style} onChange={(e) => setStyle(e.target.value)}>
                    <option value="realistic">Realistic</option>
                    <option value="cartoon">Cartoon</option>
                    <option value="anime">Anime</option>
                </select>
                <input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(parseInt(e.target.value))}
                    placeholder="Duration in seconds"
                />
                <button type="submit" disabled={loading}>
                    {loading ? 'Generating...' : 'Generate Video'}
                </button>
            </form>
            {error && <p>{error}</p>}
            {videoUrl && <video src={videoUrl} controls />}
        </div>
    );
};

export default VideoGenerator;
