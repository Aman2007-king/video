from django.http import JsonResponse
from rest_framework import status

class UsageLimitMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = request.user
        if not user.is_authenticated:
            return self.get_response(request)

        if request.path == '/api/generate-image/':
            if user.image_generations_remaining <= 0:
                return JsonResponse(
                    {'error': 'You have run out of free image generations.'},
                    status=status.HTTP_402_PAYMENT_REQUIRED
                )
            user.image_generations_remaining -= 1
            user.save()
        elif request.path == '/api/generate-video/':
            if user.video_generations_remaining <= 0:
                return JsonResponse(
                    {'error': 'You have run out of free video generations.'},
                    status=status.HTTP_402_PAYMENT_REQUIRED
                )
            user.video_generations_remaining -= 1
            user.save()

        return self.get_response(request)
