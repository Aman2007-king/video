from django.apps import AppConfig


class VoiceGenerationConfig(AppConfig):
    name = "voice_generation"
