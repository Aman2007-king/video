from django.urls import path
from .views import VoiceGenerationView

urlpatterns = [
    path('generate-voice/', VoiceGenerationView.as_view(), name='generate-voice'),
]
