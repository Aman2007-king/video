from django.apps import AppConfig


class ImageGenerationConfig(AppConfig):
    name = "image_generation"
