from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
import requests

class ImageGenerationView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        prompt = request.data.get('prompt')
        if not prompt:
            return Response({'error': 'Prompt is required'}, status=400)

        response = requests.post(
            "https://api.deepai.org/api/text2img",
            data={
                'text': prompt,
            },
            headers={'api-key': 'YOUR_DEEPAI_API_KEY'}
        )

        if response.status_code == 200:
            return Response(response.json())
        else:
            return Response({'error': 'Failed to generate image'}, status=response.status_code)
