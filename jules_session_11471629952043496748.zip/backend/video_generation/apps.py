from django.apps import AppConfig


class VideoGenerationConfig(AppConfig):
    name = "video_generation"
